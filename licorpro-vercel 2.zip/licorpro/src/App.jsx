import { useState, useEffect, useRef } from "react";

const INITIAL_INVENTORY = [
  // WHISKY
  { id: 1, name: "Jack Daniel's", category: "Whisky", unit: "750ml", stock: 6, backup: 12, par: 3, salesRate: 4, trend: "up", price: 28 },
  { id: 2, name: "Johnnie Walker Black", category: "Whisky", unit: "750ml", stock: 4, backup: 8, par: 3, salesRate: 3, trend: "stable", price: 35 },
  { id: 3, name: "Jameson Irish Whiskey", category: "Whisky", unit: "750ml", stock: 5, backup: 10, par: 2, salesRate: 3, trend: "up", price: 30 },
  // VODKA
  { id: 4, name: "Absolut Vodka", category: "Vodka", unit: "750ml", stock: 8, backup: 16, par: 4, salesRate: 5, trend: "up", price: 22 },
  { id: 5, name: "Grey Goose", category: "Vodka", unit: "750ml", stock: 3, backup: 6, par: 3, salesRate: 2, trend: "stable", price: 42 },
  { id: 6, name: "Tito's Handmade", category: "Vodka", unit: "750ml", stock: 7, backup: 14, par: 4, salesRate: 5, trend: "up", price: 25 },
  // RON
  { id: 7, name: "Bacardi Superior", category: "Ron", unit: "750ml", stock: 9, backup: 18, par: 4, salesRate: 6, trend: "up", price: 18 },
  { id: 8, name: "Captain Morgan Spiced", category: "Ron", unit: "750ml", stock: 5, backup: 10, par: 3, salesRate: 4, trend: "stable", price: 20 },
  { id: 9, name: "Havana Club 7 Años", category: "Ron", unit: "750ml", stock: 3, backup: 6, par: 2, salesRate: 2, trend: "down", price: 32 },
  // TEQUILA
  { id: 10, name: "Jose Cuervo Especial", category: "Tequila", unit: "750ml", stock: 6, backup: 12, par: 3, salesRate: 4, trend: "up", price: 24 },
  { id: 11, name: "Patron Silver", category: "Tequila", unit: "750ml", stock: 4, backup: 8, par: 3, salesRate: 3, trend: "up", price: 50 },
  { id: 12, name: "Don Julio Blanco", category: "Tequila", unit: "750ml", stock: 2, backup: 4, par: 2, salesRate: 2, trend: "stable", price: 55 },
  // GIN
  { id: 13, name: "Tanqueray London Dry", category: "Gin", unit: "750ml", stock: 4, backup: 8, par: 2, salesRate: 3, trend: "stable", price: 28 },
  { id: 14, name: "Hendrick's Gin", category: "Gin", unit: "750ml", stock: 3, backup: 6, par: 2, salesRate: 2, trend: "up", price: 38 },
  // COGNAC / BRANDY
  { id: 15, name: "Hennessy VS", category: "Cognac", unit: "750ml", stock: 5, backup: 10, par: 3, salesRate: 4, trend: "up", price: 45 },
  { id: 16, name: "Rémy Martin VSOP", category: "Cognac", unit: "750ml", stock: 2, backup: 4, par: 2, salesRate: 2, trend: "stable", price: 55 },
  // LICORES
  { id: 17, name: "Baileys Original", category: "Licor", unit: "750ml", stock: 4, backup: 8, par: 2, salesRate: 2, trend: "stable", price: 28 },
  { id: 18, name: "Kahlúa", category: "Licor", unit: "750ml", stock: 3, backup: 6, par: 2, salesRate: 2, trend: "stable", price: 24 },
  // CERVEZAS
  { id: 19, name: "Modelo Especial", category: "Cerveza", unit: "355ml lata", stock: 48, backup: 96, par: 24, salesRate: 30, trend: "up", price: 2.5 },
  { id: 20, name: "Corona Extra", category: "Cerveza", unit: "355ml lata", stock: 36, backup: 72, par: 24, salesRate: 25, trend: "up", price: 2.5 },
  { id: 21, name: "Heineken", category: "Cerveza", unit: "355ml lata", stock: 24, backup: 48, par: 18, salesRate: 18, trend: "stable", price: 3 },
  // SODAS & MEZCLADORES
  { id: 22, name: "Club Soda Schweppes", category: "Soda", unit: "355ml lata", stock: 48, backup: 96, par: 24, salesRate: 35, trend: "up", price: 1.5 },
  { id: 23, name: "Tonic Water Schweppes", category: "Soda", unit: "355ml lata", stock: 36, backup: 72, par: 24, salesRate: 28, trend: "up", price: 1.5 },
  { id: 24, name: "Canada Dry Ginger Ale", category: "Soda", unit: "355ml lata", stock: 30, backup: 60, par: 18, salesRate: 20, trend: "stable", price: 1.5 },
  { id: 25, name: "Coca-Cola", category: "Soda", unit: "355ml lata", stock: 60, backup: 120, par: 36, salesRate: 45, trend: "up", price: 1.5 },
  { id: 26, name: "Sprite / Sierra Mist", category: "Soda", unit: "355ml lata", stock: 48, backup: 96, par: 24, salesRate: 30, trend: "stable", price: 1.5 },
  { id: 27, name: "Red Bull Original", category: "Soda", unit: "250ml lata", stock: 24, backup: 48, par: 12, salesRate: 18, trend: "up", price: 3.5 },
  { id: 28, name: "Red Bull Sugar Free", category: "Soda", unit: "250ml lata", stock: 18, backup: 36, par: 12, salesRate: 12, trend: "stable", price: 3.5 },
  // JUGOS
  { id: 29, name: "Jugo de Naranja Tropicana", category: "Jugo", unit: "1L", stock: 12, backup: 24, par: 6, salesRate: 10, trend: "up", price: 4 },
  { id: 30, name: "Jugo de Piña Dole", category: "Jugo", unit: "1L", stock: 10, backup: 20, par: 6, salesRate: 8, trend: "up", price: 4 },
  { id: 31, name: "Jugo de Arándano Ocean Spray", category: "Jugo", unit: "1L", stock: 8, backup: 16, par: 4, salesRate: 7, trend: "stable", price: 4.5 },
  { id: 32, name: "Jugo de Tomate / Clamato", category: "Jugo", unit: "1L", stock: 6, backup: 12, par: 4, salesRate: 5, trend: "stable", price: 3.5 },
  { id: 33, name: "Jugo de Mango", category: "Jugo", unit: "1L", stock: 8, backup: 16, par: 4, salesRate: 6, trend: "up", price: 4 },
  { id: 34, name: "Agua de Coco Vita Coco", category: "Jugo", unit: "330ml", stock: 18, backup: 36, par: 10, salesRate: 12, trend: "up", price: 3 },
];

const CATEGORIES = ["Todos", "Whisky", "Vodka", "Ron", "Tequila", "Gin", "Cognac", "Licor", "Cerveza", "Soda", "Jugo"];
const CATEGORY_EMOJI = { Todos: "🍾", Whisky: "🥃", Vodka: "🍸", Ron: "🍹", Tequila: "🌵", Gin: "🍃", Cognac: "✨", Licor: "🍫", Cerveza: "🍺", Soda: "🥤", Jugo: "🍊" };
const CATEGORY_UNITS = { Whisky: "750ml", Vodka: "750ml", Ron: "750ml", Tequila: "750ml", Gin: "750ml", Cognac: "750ml", Licor: "750ml", Cerveza: "355ml lata", Soda: "355ml lata", Jugo: "1L" };

let nextId = 100;

export default function LiquorInventory() {
  const [inventory, setInventory] = useState(INITIAL_INVENTORY);
  const [filter, setFilter] = useState("Todos");
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [aiPanel, setAiPanel] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState("");
  const [newItem, setNewItem] = useState({ name: "", category: "Whisky", unit: "750ml", stock: 0, backup: 0, par: 2, price: 0 });
  const [editingPar, setEditingPar] = useState(null);
  const [editParVal, setEditParVal] = useState("");
  const parInputRef = useRef(null);

  useEffect(() => {
    if (editingPar !== null && parInputRef.current) parInputRef.current.focus();
  }, [editingPar]);

  const filtered = inventory.filter(item => {
    const matchCat = filter === "Todos" || item.category === filter;
    const matchSearch = item.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const totalItems = inventory.length;
  const criticalItems = inventory.filter(i => i.stock <= i.par).length;
  const totalBackup = inventory.reduce((sum, i) => sum + i.backup, 0);

  const adjustStock = (id, field, delta) => {
    setInventory(prev => prev.map(item =>
      item.id === id ? { ...item, [field]: Math.max(0, item[field] + delta) } : item
    ));
  };

  const removeItem = (id) => setInventory(prev => prev.filter(i => i.id !== id));

  const addItem = () => {
    if (!newItem.name.trim()) return;
    setInventory(prev => [...prev, { ...newItem, id: nextId++, salesRate: 2, trend: "stable" }]);
    setNewItem({ name: "", category: "Whisky", unit: "750ml", stock: 0, backup: 0, par: 2, price: 0 });
    setShowAdd(false);
  };

  const savePar = (id) => {
    const val = parseInt(editParVal);
    if (!isNaN(val) && val >= 0) {
      setInventory(prev => prev.map(item => item.id === id ? { ...item, par: val } : item));
    }
    setEditingPar(null);
  };

  const getStatus = (item) => {
    if (item.stock <= item.par) return "critical";
    if (item.stock <= item.par * 1.5) return "low";
    return "ok";
  };

  const getTrendIcon = (t) => t === "up" ? "↑" : t === "down" ? "↓" : "→";
  const getTrendColor = (t) => t === "up" ? "#4ade80" : t === "down" ? "#f87171" : "#94a3b8";

  const runAIAnalysis = async () => {
    setAiLoading(true);
    setAiPanel(true);
    setAiResult("");

    const summary = inventory.map(i =>
      `${i.name} (${i.category}): stock=${i.stock}, backup=${i.backup}, par=${i.par}, ventas/semana=${i.salesRate}, tendencia=${i.trend}`
    ).join("\n");

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{
            role: "user",
            content: `Eres un agente de ventas experto en licorería. Analiza este inventario y detecta patrones. 
Responde en ESPAÑOL con formato estructurado:

1. 🚨 ALERTAS CRÍTICAS (productos que necesitan restock urgente)
2. 📈 PATRONES DETECTADOS (tendencias de venta, qué se mueve más)
3. 🛒 RECOMENDACIONES DE COMPRA esta semana (qué y cuánto comprar)
4. 💡 ESTRATEGIA (cómo optimizar el inventario para maximizar ventas)

INVENTARIO ACTUAL:
${summary}

Sé específico con nombres de productos y cantidades. Máximo 300 palabras.`
          }]
        })
      });
      const data = await response.json();
      const text = data.content?.map(b => b.text || "").join("") || "Error al analizar.";
      setAiResult(text);
    } catch (e) {
      setAiResult("⚠️ Error de conexión con el agente IA. Intenta de nuevo.");
    }
    setAiLoading(false);
  };

  const statusColor = { critical: "#ef4444", low: "#f59e0b", ok: "#22c55e" };
  const statusBg = { critical: "rgba(239,68,68,0.08)", low: "rgba(245,158,11,0.08)", ok: "transparent" };

  return (
    <div style={{
      minHeight: "100vh", background: "#0a0a0f",
      fontFamily: "'DM Sans', 'Segoe UI', sans-serif", color: "#e2e8f0",
      backgroundImage: "radial-gradient(ellipse at 20% 10%, rgba(139,92,246,0.08) 0%, transparent 50%), radial-gradient(ellipse at 80% 80%, rgba(16,185,129,0.06) 0%, transparent 50%)"
    }}>
      {/* Header */}
      <div style={{ background: "rgba(255,255,255,0.03)", borderBottom: "1px solid rgba(255,255,255,0.07)", padding: "16px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: 900, margin: "0 auto" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 28 }}>🍾</span>
              <div>
                <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: "-0.5px", color: "#f1f5f9" }}>LicorPro</div>
                <div style={{ fontSize: 11, color: "#64748b", letterSpacing: "2px", textTransform: "uppercase" }}>Sistema de Inventario</div>
              </div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={runAIAnalysis} style={{
              background: "linear-gradient(135deg, #7c3aed, #4f46e5)", border: "none", borderRadius: 10,
              color: "#fff", padding: "9px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer",
              display: "flex", alignItems: "center", gap: 6
            }}>
              🤖 Análisis IA
            </button>
            <button onClick={() => setShowAdd(true)} style={{
              background: "linear-gradient(135deg, #059669, #0d9488)", border: "none", borderRadius: 10,
              color: "#fff", padding: "9px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer"
            }}>
              + Añadir
            </button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: "0 auto", padding: "16px 12px" }}>
        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 16 }}>
          {[
            { label: "Productos", value: totalItems, icon: "📦", color: "#818cf8" },
            { label: "Stock Crítico", value: criticalItems, icon: "🚨", color: "#f87171" },
            { label: "Total Backup", value: totalBackup, icon: "🛡️", color: "#34d399" }
          ].map(s => (
            <div key={s.label} style={{
              background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)",
              borderRadius: 12, padding: "12px 14px"
            }}>
              <div style={{ fontSize: 20 }}>{s.icon}</div>
              <div style={{ fontSize: 22, fontWeight: 700, color: s.color, lineHeight: 1.2 }}>{s.value}</div>
              <div style={{ fontSize: 11, color: "#64748b" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Search */}
        <input
          placeholder="🔍 Buscar producto..."
          value={search} onChange={e => setSearch(e.target.value)}
          style={{
            width: "100%", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: 10, padding: "10px 14px", color: "#e2e8f0", fontSize: 14, outline: "none",
            boxSizing: "border-box", marginBottom: 12
          }}
        />

        {/* Category Filter */}
        <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 4, marginBottom: 14, scrollbarWidth: "none" }}>
          {CATEGORIES.map(cat => (
            <button key={cat} onClick={() => setFilter(cat)} style={{
              background: filter === cat ? "linear-gradient(135deg, #7c3aed, #4f46e5)" : "rgba(255,255,255,0.05)",
              border: filter === cat ? "none" : "1px solid rgba(255,255,255,0.08)",
              borderRadius: 20, padding: "6px 14px", color: filter === cat ? "#fff" : "#94a3b8",
              fontSize: 12, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap"
            }}>
              {CATEGORY_EMOJI[cat]} {cat}
            </button>
          ))}
        </div>

        {/* Inventory Table */}
        <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, overflow: "hidden" }}>
          {/* Table Header */}
          <div style={{
            display: "grid", gridTemplateColumns: "1fr 70px 70px 56px 40px 30px",
            padding: "10px 14px", background: "rgba(255,255,255,0.04)",
            borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: 10,
            color: "#64748b", letterSpacing: "1px", textTransform: "uppercase", fontWeight: 600
          }}>
            <span>Producto</span>
            <span style={{ textAlign: "center" }}>Stock</span>
            <span style={{ textAlign: "center" }}>Backup</span>
            <span style={{ textAlign: "center" }}>Mín ✏️</span>
            <span style={{ textAlign: "center" }}>Tend.</span>
            <span></span>
          </div>

          {filtered.length === 0 && (
            <div style={{ padding: 30, textAlign: "center", color: "#475569" }}>No se encontraron productos</div>
          )}

          {filtered.map((item, idx) => {
            const status = getStatus(item);
            return (
              <div key={item.id} style={{
                display: "grid", gridTemplateColumns: "1fr 70px 70px 56px 40px 30px",
                padding: "11px 14px", borderBottom: idx < filtered.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none",
                background: statusBg[status], alignItems: "center",
                transition: "background 0.2s"
              }}>
                {/* Name & Category */}
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    {status === "critical" && <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#ef4444", display: "inline-block", flexShrink: 0 }}></span>}
                    {status === "low" && <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#f59e0b", display: "inline-block", flexShrink: 0 }}></span>}
                    <span style={{ fontSize: 13, fontWeight: 600, color: status === "critical" ? "#fca5a5" : "#e2e8f0" }}>{item.name}</span>
                  </div>
                  <div style={{ fontSize: 10, color: "#475569", marginTop: 1 }}>
                    {CATEGORY_EMOJI[item.category]} {item.category} · {item.unit} · ${item.price}
                  </div>
                </div>

                {/* Stock */}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 4 }}>
                  <button onClick={() => adjustStock(item.id, "stock", -1)} style={btnStyle("#1e293b")}>−</button>
                  <span style={{ fontSize: 14, fontWeight: 700, color: statusColor[status], minWidth: 22, textAlign: "center" }}>{item.stock}</span>
                  <button onClick={() => adjustStock(item.id, "stock", 1)} style={btnStyle("#1e293b")}>+</button>
                </div>

                {/* Backup */}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 4 }}>
                  <button onClick={() => adjustStock(item.id, "backup", -1)} style={btnStyle("#0f172a")}>−</button>
                  <span style={{ fontSize: 13, color: "#94a3b8", minWidth: 22, textAlign: "center" }}>{item.backup}</span>
                  <button onClick={() => adjustStock(item.id, "backup", 1)} style={btnStyle("#0f172a")}>+</button>
                </div>

                {/* Par (editable) */}
                <div style={{ textAlign: "center" }}>
                  {editingPar === item.id ? (
                    <input
                      ref={parInputRef}
                      value={editParVal}
                      onChange={e => setEditParVal(e.target.value)}
                      onBlur={() => savePar(item.id)}
                      onKeyDown={e => { if (e.key === "Enter") savePar(item.id); if (e.key === "Escape") setEditingPar(null); }}
                      style={{ width: 36, background: "#1e293b", border: "1px solid #7c3aed", borderRadius: 5, color: "#e2e8f0", textAlign: "center", fontSize: 13, padding: "2px 0", outline: "none" }}
                    />
                  ) : (
                    <span onClick={() => { setEditingPar(item.id); setEditParVal(String(item.par)); }}
                      style={{ fontSize: 13, color: "#94a3b8", cursor: "pointer", textDecoration: "underline dotted", textDecorationColor: "#475569" }}>
                      {item.par}
                    </span>
                  )}
                </div>

                {/* Trend */}
                <div style={{ textAlign: "center", fontSize: 15, color: getTrendColor(item.trend) }}>
                  {getTrendIcon(item.trend)}
                </div>

                {/* Delete */}
                <button onClick={() => removeItem(item.id)} style={{
                  background: "transparent", border: "none", color: "#475569", cursor: "pointer",
                  fontSize: 14, padding: "2px 4px", borderRadius: 4,
                  transition: "color 0.2s"
                }} onMouseEnter={e => e.target.style.color = "#ef4444"} onMouseLeave={e => e.target.style.color = "#475569"}>
                  ✕
                </button>
              </div>
            );
          })}
        </div>

        <div style={{ marginTop: 10, fontSize: 11, color: "#334155", textAlign: "center" }}>
          Toca el número en columna Mín para editar · ↑ subiendo · → estable · ↓ bajando
        </div>
      </div>

      {/* Add Modal */}
      {showAdd && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)", display: "flex", alignItems: "flex-end", zIndex: 50 }}>
          <div style={{
            width: "100%", background: "#0f172a", borderTop: "1px solid rgba(255,255,255,0.1)",
            borderRadius: "20px 20px 0 0", padding: 24, maxHeight: "85vh", overflowY: "auto"
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
              <span style={{ fontSize: 16, fontWeight: 700 }}>➕ Nuevo Producto</span>
              <button onClick={() => setShowAdd(false)} style={{ background: "none", border: "none", color: "#94a3b8", fontSize: 20, cursor: "pointer" }}>✕</button>
            </div>

            {[
              { label: "Nombre del producto", key: "name", type: "text", placeholder: "Ej: Johnnie Walker Blue" },
              { label: "Precio ($)", key: "price", type: "number", placeholder: "0" },
              { label: "Stock actual", key: "stock", type: "number", placeholder: "0" },
              { label: "Cantidad backup", key: "backup", type: "number", placeholder: "0" },
              { label: "Mínimo (par)", key: "par", type: "number", placeholder: "2" },
            ].map(f => (
              <div key={f.key} style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 12, color: "#64748b", display: "block", marginBottom: 5 }}>{f.label}</label>
                <input type={f.type} placeholder={f.placeholder} value={newItem[f.key]}
                  onChange={e => setNewItem(p => ({ ...p, [f.key]: f.type === "number" ? Number(e.target.value) : e.target.value }))}
                  style={{ width: "100%", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 9, padding: "10px 12px", color: "#e2e8f0", fontSize: 14, outline: "none", boxSizing: "border-box" }}
                />
              </div>
            ))}

            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: "#64748b", display: "block", marginBottom: 5 }}>Categoría</label>
              <select value={newItem.category}
                onChange={e => setNewItem(p => ({ ...p, category: e.target.value, unit: CATEGORY_UNITS[e.target.value] || "750ml" }))}
                style={{ width: "100%", background: "#1e293b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 9, padding: "10px 12px", color: "#e2e8f0", fontSize: 14, outline: "none" }}>
                {CATEGORIES.filter(c => c !== "Todos").map(c => <option key={c}>{c}</option>)}
              </select>
            </div>

            <button onClick={addItem} style={{
              width: "100%", background: "linear-gradient(135deg, #059669, #0d9488)", border: "none",
              borderRadius: 12, color: "#fff", padding: 14, fontSize: 15, fontWeight: 700, cursor: "pointer", marginTop: 6
            }}>
              Agregar al Inventario
            </button>
          </div>
        </div>
      )}

      {/* AI Analysis Panel */}
      {aiPanel && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", display: "flex", alignItems: "flex-end", zIndex: 50 }}>
          <div style={{
            width: "100%", background: "#0d0d1a", borderTop: "1px solid rgba(124,58,237,0.4)",
            borderRadius: "20px 20px 0 0", padding: 24, maxHeight: "80vh", overflowY: "auto"
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 20 }}>🤖</span>
                <span style={{ fontSize: 16, fontWeight: 700, background: "linear-gradient(135deg, #a78bfa, #60a5fa)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                  Agente IA — Análisis de Inventario
                </span>
              </div>
              <button onClick={() => setAiPanel(false)} style={{ background: "none", border: "none", color: "#94a3b8", fontSize: 20, cursor: "pointer" }}>✕</button>
            </div>

            {aiLoading ? (
              <div style={{ textAlign: "center", padding: "40px 0" }}>
                <div style={{ fontSize: 32, marginBottom: 12 }}>⏳</div>
                <div style={{ color: "#7c3aed", fontSize: 14 }}>Analizando patrones de inventario...</div>
              </div>
            ) : (
              <div style={{
                background: "rgba(124,58,237,0.08)", border: "1px solid rgba(124,58,237,0.2)",
                borderRadius: 12, padding: 16, fontSize: 14, lineHeight: 1.7, color: "#cbd5e1",
                whiteSpace: "pre-wrap"
              }}>
                {aiResult}
              </div>
            )}

            {!aiLoading && (
              <button onClick={runAIAnalysis} style={{
                width: "100%", background: "linear-gradient(135deg, #7c3aed, #4f46e5)",
                border: "none", borderRadius: 12, color: "#fff", padding: 12, fontSize: 14,
                fontWeight: 600, cursor: "pointer", marginTop: 14
              }}>
                🔄 Re-analizar
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function btnStyle(bg) {
  return {
    background: bg, border: "1px solid rgba(255,255,255,0.08)", borderRadius: 5,
    color: "#94a3b8", width: 20, height: 20, fontSize: 13, cursor: "pointer",
    display: "flex", alignItems: "center", justifyContent: "center", padding: 0, flexShrink: 0
  };
}
