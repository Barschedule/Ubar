# 🍾 LicorPro — Guía de Deployment en Vercel

## ¿Qué necesitas?
- Una cuenta gratuita en [vercel.com](https://vercel.com)
- Una cuenta gratuita en [github.com](https://github.com)
- El archivo ZIP de este proyecto (que ya tienes)

---

## PASO 1 — Sube el proyecto a GitHub

1. Ve a [github.com](https://github.com) e inicia sesión
2. Clic en **"New repository"** (botón verde)
3. Ponle nombre: `licorpro`
4. Deja todo por defecto → clic en **"Create repository"**
5. En la página que aparece, clic en **"uploading an existing file"**
6. **Arrastra todos los archivos** de esta carpeta (descomprime el ZIP primero)
7. Clic en **"Commit changes"**

---

## PASO 2 — Conecta con Vercel

1. Ve a [vercel.com](https://vercel.com) → **"Sign Up"** con tu cuenta de GitHub
2. Clic en **"Add New Project"**
3. Selecciona el repositorio `licorpro`
4. Vercel detecta automáticamente que es Vite/React ✅
5. Clic en **"Deploy"**
6. ¡Espera ~60 segundos!

---

## PASO 3 — Obtén tu link

Vercel te da un link tipo:
```
https://licorpro.vercel.app
```

✅ **Ese link funciona en cualquier celular, tablet o computadora.**
Compártelo con tu equipo — no necesitan instalar nada.

---

## PASO 4 — Agrega tu API Key de Anthropic (para el botón IA)

El análisis IA necesita tu clave de Anthropic:

1. Ve a [console.anthropic.com](https://console.anthropic.com) → **API Keys** → crea una
2. En Vercel → tu proyecto → **Settings** → **Environment Variables**
3. Agrega:
   - **Name:** `VITE_ANTHROPIC_API_KEY`
   - **Value:** tu clave (empieza con `sk-ant-...`)
4. Clic **Save** → luego **Redeploy**

---

## Actualizaciones futuras

Cada vez que subas cambios a GitHub, Vercel actualiza la app automáticamente en ~30 segundos. No necesitas hacer nada más.

---

## Estructura del proyecto

```
licorpro/
├── index.html          ← Entrada principal
├── package.json        ← Dependencias
├── vite.config.js      ← Configuración de build
├── vercel.json         ← Configuración de deployment
└── src/
    ├── main.jsx        ← Punto de entrada React
    └── App.jsx         ← Tu app completa (inventario + IA)
```

---

## ¿Problemas?

- **La app no carga:** Verifica que subiste todos los archivos incluyendo la carpeta `src/`
- **El botón IA no funciona:** Revisa que la API key esté configurada en Vercel
- **Cambios no se ven:** Haz "Redeploy" en el dashboard de Vercel

---

*LicorPro v1.0 — Hecho con Claude AI*
